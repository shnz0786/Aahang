import pandas as pd
import re
import unicodedata
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .models import Poem

class UrduPoetryEngine:
    _instance = None

    def __new__(cls):
        # Singleton pattern to ensure we only train the model once
        if cls._instance is None:
            cls._instance = super(UrduPoetryEngine, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
            
        self.vectorizer = TfidfVectorizer(analyzer='char_wb', ngram_range=(2, 5))
        self.tfidf_matrix = None
        self.data_cache = []
        self._load_and_train()
        self._initialized = True

    def normalize_text(self, text):
        if not isinstance(text, str):
            return ""
        
        text = unicodedata.normalize('NFC', text)
        text = text.lower().strip()
        # Remove diacritics
        text = re.sub(r'[\u064B-\u065F\u0670\u0610-\u061A]', '', text)

        replacements = [
            (r'[آأإعٱ]', 'ا'), (r'[ط]', 'ت'), (r'[ثص]', 'س'),
            (r'[ذضظژج]', 'ز'), (r'[حھ]', 'ہ'), (r'[ق]', 'ک'),
            (r'[ں]', 'ن'), (r'[ے]', 'ی'), (r'[ـ۔،,]', ''),
        ]

        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text)

        return text

    def _load_and_train(self):
        print("[INFO] Loading poems from Django DB...")
        # Fetch all poems from the database
        poems = Poem.objects.all().values('id', 'poet_name', 'poem_text')
        df = pd.DataFrame(list(poems))

        if not df.empty:
            df['poem_text'] = df['poem_text'].astype(str)
            self.data_cache = df.to_dict('records')

            print("[INFO] Normalizing database for fuzzy search...")
            training_corpus = df['poem_text'].apply(self.normalize_text)

            print("[INFO] Training Model...")
            self.tfidf_matrix = self.vectorizer.fit_transform(training_corpus)
            print(f"[INFO] Engine Ready! Loaded {len(df)} poems.")
        else:
            print("[WARNING] Database empty. Please run the load_ghazals command.")

    def search(self, query, top_n=1):
        if not query.strip() or self.tfidf_matrix is None:
            return []

        norm_query = self.normalize_text(query)
        query_vec = self.vectorizer.transform([norm_query])
        
        # Calculate cosine similarity
        cosine_similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        
        # Get top indices
        related_docs_indices = cosine_similarities.argsort()[:-top_n-1:-1]

        results = []
        for idx in related_docs_indices:
            score = cosine_similarities[idx]
            if score < 0.1: continue

            match = self.data_cache[idx]
            results.append({
                'poet': match.get('poet_name', 'Unknown'),
                'full_text': match['poem_text'],
                'score': round(score, 3) # Round for cleaner display
            })
        return results

    def reload(self):
        """Helper to force retrain if new data is added via admin"""
        self._load_and_train()