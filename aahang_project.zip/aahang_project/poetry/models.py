from django.db import models

class Poem(models.Model):
    poet_name = models.CharField(max_length=255, default='Unknown')
    poem_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.poet_name} - {self.poem_text[:30]}..."