import os
import pandas as pd
from django.core.management.base import BaseCommand
from poetry.models import Poem
from poetry.search_engine import UrduPoetryEngine

class Command(BaseCommand):
    help = 'Load ghazals from a CSV file'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str, help='Path to the CSV file')

    def handle(self, *args, **kwargs):
        csv_path = kwargs['csv_file']
        
        if not os.path.exists(csv_path):
            self.stdout.write(self.style.ERROR(f"File not found: {csv_path}"))
            return

        self.stdout.write(f"Loading data from {csv_path}...")
        
        try:
            df = pd.read_csv(csv_path)
            
            # Column mapping logic from your original script
            cols = df.columns.str.lower()
            rename_map = {}
            
            text_candidates = [c for c in cols if any(x in c for x in ['poetry', 'text', 'sher', 'ghazal', 'content'])]
            poet_candidates = [c for c in cols if any(x in c for x in ['poet', 'author', 'name'])]

            if text_candidates:
                rename_map[df.columns[cols.get_loc(text_candidates[0])]] = 'poem_text'
            else:
                rename_map[df.columns[0]] = 'poem_text'

            if poet_candidates:
                 rename_map[df.columns[cols.get_loc(poet_candidates[0])]] = 'poet_name'
            elif len(df.columns) > 1:
                 rename_map[df.columns[1]] = 'poet_name'

            df = df.rename(columns=rename_map)
            
            # Bulk create objects for speed
            poems_to_create = [
                Poem(
                    poet_name=row.get('poet_name', 'Unknown'), 
                    poem_text=row['poem_text']
                ) 
                for _, row in df.iterrows()
            ]
            
            Poem.objects.all().delete() # Clear old data
            Poem.objects.bulk_create(poems_to_create)
            
            self.stdout.write(self.style.SUCCESS(f"Successfully loaded {len(poems_to_create)} poems."))
            
            # Reload the engine
            UrduPoetryEngine().reload()
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error loading CSV: {e}"))