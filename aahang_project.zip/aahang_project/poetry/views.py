from django.shortcuts import render
from .search_engine import UrduPoetryEngine

def search_view(request):
    query = request.GET.get('q', '')
    results = []
    
    if query:
        # Initialize engine (it will reuse the loaded data if already running)
        engine = UrduPoetryEngine()
        results = engine.search(query, top_n=1)

    return render(request, 'poetry/index.html', {'query': query, 'results': results})